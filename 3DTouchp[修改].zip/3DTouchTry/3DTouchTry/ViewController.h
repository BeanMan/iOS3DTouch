//
//  ViewController.h
//  3DTouchTry
//
//  Created by bean on 16/2/15.
//  Copyright © 2016年 com.xile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController



@property(nonatomic,copy)NSString * abc;

@end

