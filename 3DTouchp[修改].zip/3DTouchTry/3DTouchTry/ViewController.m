//
//  ViewController.m
//  3DTouchTry
//
//  Created by bean on 16/2/15.
//  Copyright © 2016年 com.xile. All rights reserved.
//

#import "ViewController.h"
#import "NextViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor yellowColor];
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(100, 100, 100, 100);
    btn.backgroundColor = [UIColor redColor];
    [btn addTarget:self action:@selector(click) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
     NSLog(@"++++++%@",self.abc);
    if ([self.abc isEqualToString:@"1"]) {
        [self click];
    }
    
}

-(void)viewWillAppear:(BOOL)animated
{
   
    [super viewWillAppear:animated];
    
}

- (void)click {
    
    NextViewController * next = [[NextViewController alloc]init];
    [self.navigationController pushViewController:next animated:YES];
}



@end
